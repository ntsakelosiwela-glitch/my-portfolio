# Ntsakelo Wright | Data Analyst & BI Specialist

A single-page personal portfolio for Ntsakelo Wright Siwela, a final-year BSc Informatics student at UNISA targeting Data Analyst, BI Analyst, Business Analyst and Data Scientist roles.

The whole site is one file, `index.html`, with no build step.

## Sections

- **Hero**: introduction, target roles, core tech stack and quick contact details
- **About**: academic background, analytical expertise and professional drive
- **Skills**: databases and querying, BI and visualization (including Excel), programming and data science, business analysis
- **Experience**: Data Analyst Associate Intern (4excelerate) and Sales Consultant (Cyprus Direct Marketing)
- **Projects**: BI sales and KPI dashboard, customer churn analysis, relational database and SQL optimization
- **Certifications**: Google Advanced Data Analytics and Simplilearn data and analytics training
- **Contact**: phone, email and LinkedIn links, plus a message form that opens the visitor's email app

## Tech stack

- HTML and [Tailwind CSS](https://tailwindcss.com/) (CDN, pinned to 3.4.17)
- [Font Awesome](https://fontawesome.com/) 6.4.0 icons (script build from cdnjs)
- [Inter](https://fonts.google.com/specimen/Inter) via Google Fonts
- A little vanilla JavaScript for the mobile menu, navbar shadow and contact form

## Repository structure

```
.
├── index.html                    # the entire website
├── assets/
│   └── ntsakelo-wright.png       # original photo (the page embeds a compressed copy)
├── .github/workflows/deploy.yml  # publishes the site to GitHub Pages on every push to main
├── .nojekyll                     # tells GitHub Pages to serve the files as they are
├── .gitignore
├── LICENSE
└── README.md
```

## Run locally

Open `index.html` in any modern browser. An internet connection is needed for Tailwind, icons and fonts.

## Customise

- **Photo and logo**: the photo is embedded once as a base64 image in the `--photo` CSS variable at the top of the `<style>` block. Replace that value to change it. `.photo-logo` controls the small logo crop and `.photo-portrait` controls the hero image.
- **Theme colours**: the amber palette comes from the photo backdrop and is set in `tailwind.config` (the `brand` and `indigo` colour scales). The deep brown contact and footer sections use hard-coded values (`#2a1602`, `#3a2108`, `#170d01`).
- **Contact details**: search `index.html` for the phone number and `ntsakelosiwela@gmail.com` to update them everywhere.
- **Skills and projects**: each skill row and project card is a self-contained block you can copy and edit.

## Deploy to GitHub Pages

1. Create a new repository on GitHub (for a root address like `https://<username>.github.io`, name it `<username>.github.io`).
2. Upload all the files in this folder, keeping the folder structure, to the `main` branch.
3. In the repository, go to **Settings → Pages** and set **Source** to **GitHub Actions**.
4. The **Actions** tab will run "Deploy portfolio to GitHub Pages". When it finishes, the live link appears in **Settings → Pages**.

Every later push to `main` redeploys the site automatically.

## Contact

- Email: ntsakelosiwela@gmail.com
- LinkedIn: https://www.linkedin.com/in/ntsakelo-wright
- Location: Roodepoort, Gauteng, South Africa

## Licence

All rights reserved. See [LICENSE](LICENSE).
